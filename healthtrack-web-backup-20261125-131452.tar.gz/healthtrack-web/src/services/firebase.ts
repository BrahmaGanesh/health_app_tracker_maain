import { initializeApp, getApps, getApp } from 'firebase/app'
import { getAuth, connectAuthEmulator } from 'firebase/auth'
import { getFirestore, connectFirestoreEmulator } from 'firebase/firestore'
import { getStorage, connectStorageEmulator } from 'firebase/storage'
import { getMessaging, isSupported, getToken, onMessage } from 'firebase/messaging'

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID,
}

let app: any = null
let authInstance: any = null
let dbInstance: any = null
let storageInstance: any = null
let messagingInstance: any = null

export function getFirebaseApp() {
  if (!app) {
    app = getApps().length ? getApp() : initializeApp(firebaseConfig)
  }
  return app
}

export function getAuthInstance() {
  if (!authInstance) {
    const app = getFirebaseApp()
    authInstance = getAuth(app)
    // Uncomment for local development with emulator
    // if (import.meta.env.DEV) {
    //   connectAuthEmulator(authInstance, 'http://localhost:9099')
    // }
  }
  return authInstance
}

export function getFirestoreInstance() {
  if (!dbInstance) {
    const app = getFirebaseApp()
    dbInstance = getFirestore(app)
    // if (import.meta.env.DEV) {
    //   connectFirestoreEmulator(dbInstance, 'localhost', 8080)
    // }
  }
  return dbInstance
}

export function getStorageInstance() {
  if (!storageInstance) {
    const app = getFirebaseApp()
    storageInstance = getStorage(app)
    // if (import.meta.env.DEV) {
    //   connectStorageEmulator(storageInstance, 'localhost', 9199)
    // }
  }
  return storageInstance
}

export async function getMessagingInstance() {
  if (!messagingInstance) {
    const isSupported = await isSupported()
    if (isSupported) {
      const app = getFirebaseApp()
      messagingInstance = getMessaging(app)
    }
  }
  return messagingInstance
}

export async function requestNotificationPermission() {
  try {
    const messaging = await getMessagingInstance()
    if (!messaging) return null

    const permission = await Notification.requestPermission()
    if (permission !== 'granted') {
      console.warn('Notification permission not granted')
      return null
    }

    const vapidKey = import.meta.env.VITE_FIREBASE_VAPID_KEY
    if (!vapidKey) {
      console.warn('VAPID key not configured')
      return null
    }

    const token = await getToken(messagingInstance, { vapidKey })
    return token
  } catch (error) {
    console.error('Error getting FCM token:', error)
    return null
  }
}

export function onMessageListener(callback: (payload: any) => void) {
  return onMessage(getMessagingInstance(), callback)
}

// Export singleton instances
export const auth = getAuthInstance()
export const db = getFirestoreInstance()
export const storage = getStorageInstance()