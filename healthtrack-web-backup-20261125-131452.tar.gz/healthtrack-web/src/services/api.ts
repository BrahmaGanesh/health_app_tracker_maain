import axios, { AxiosInstance } from 'axios'

const API_BASE_URL = import.meta.env.VITE_API_URL || '/api/v1'

class ApiService {
  private client: AxiosInstance

  constructor() {
    this.client = axios.create({
      baseURL: API_BASE_URL,
      timeout: 15000,
    })

    this.client.interceptors.request.use(
      (config) => {
        const token = localStorage.getItem('access_token')
        if (token) {
          config.headers.Authorization = `Bearer ${token}`
        }
        return config
      },
      (error) => Promise.reject(error)
    )

    this.client.interceptors.response.use(
      (response) => response,
      async (error) => {
        if (error.response?.status === 401) {
          const refreshToken = localStorage.getItem('refresh_token')
          if (refreshToken) {
            try {
              const response = await axios.post(`${API_BASE_URL}/auth/refresh`, {
                refresh_token: refreshToken,
              })
              const newToken = response.data.data?.access_token
              if (newToken) {
                localStorage.setItem('access_token', newToken)
              }
            } catch (refreshError) {
              localStorage.removeItem('access_token')
              localStorage.removeItem('refresh_token')
            }
          }
        }
        return Promise.reject(error)
      }
    )
  }

  async login(email: string, password: string, fcmToken?: string) {
    const response = await this.client.post('/auth/login', {
      email,
      password,
      fcm_token: fcmToken || '',
    })
    if (response.data.success && response.data.data?.access_token) {
      localStorage.setItem('access_token', response.data.data.access_token)
      if (response.data.data.refresh_token) {
        localStorage.setItem('refresh_token', response.data.data.refresh_token)
      }
    }
    return response.data
  }

  async register(name: string, email: string, password: string) {
    return this.client.post('/auth/register', { name, email, password })
  }

  async logout() {
    localStorage.removeItem('access_token')
    localStorage.removeItem('refresh_token')
    return this.client.post('/auth/logout')
  }

  async getDashboard() {
    return this.client.get('/dashboard/')
  }

  async getBP(days?: number) {
    return this.client.get(`/tracker/bp${days ? `?days=${days}` : ''}`)
  }

  async addBP(systolic: number, diastolic: number, pulse?: number, notes?: string) {
    return this.client.post('/tracker/bp', { systolic, diastolic, pulse, notes })
  }

  async getWeight(days?: number) {
    return this.client.get(`/tracker/weight${days ? `?days=${days}` : ''}`)
  }

  async addWater(litres: number) {
    return this.client.post('/tracker/water', { amount_litres: litres })
  }

  async getWaterToday() {
    return this.client.get('/tracker/water/today')
  }

  async getSteps(days?: number) {
    return this.client.get(`/tracker/steps${days ? `?days=${days}` : ''}`)
  }

  async getSleep(days?: number) {
    return this.client.get(`/tracker/sleep${days ? `?days=${days}` : ''}`)
  }

  async getSugar(days?: number) {
    return this.client.get(`/tracker/sugar${days ? `?days=${days}` : ''}`)
  }

  async getNotifications(unreadOnly = false) {
    return this.client.get(`/notifications/?unread_only=${unreadOnly}`)
  }

  async markNotificationRead(id: number) {
    return this.client.post(`/notifications/${id}/read`)
  }

  async getMedicines() {
    return this.client.get('/medicines/')
  }

  async addMedicine(data: any) {
    return this.client.post('/medicines/', data)
  }

  async deleteMedicine(id: number) {
    return this.client.delete(`/medicines/${id}`)
  }

  async logMedicineTaken(id: number, taken: boolean) {
    return this.client.post(`/medicines/${id}/log`, { taken })
  }

  async getLabTests(category = 'blood_sugar') {
    return this.client.get(`/lab-tests/?test_category=${category}`)
  }

  async getAppointments() {
    return this.client.get('/appointments/')
  }

  async addAppointment(data: any) {
    return this.client.post('/appointments/', data)
  }

  async getDocuments() {
    return this.client.get('/documents/list')
  }

  async sendAiMessage(message: string, history?: Array<{ role: string; content: string }>) {
    return this.client.post('/ai-assistant/chat', { message, history })
  }

  async getHealthScore(date?: string) {
    const url = date ? `/health-score/?date=${date}` : '/health-score/'
    return this.client.get(url)
  }

  async getFamilyMembers() {
    return this.client.get('/family/members')
  }

  async addFamilyMember(data: any) {
    return this.client.post('/family/members', data)
  }
}

export const apiService = new ApiService()

export default apiService